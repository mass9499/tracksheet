<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Leaves_model extends CI_Model {

	public function getuser_tasks($user_id)
	{
		$this->db->select('t1.*, t2.*');
		$this->db->from('tasks t1');
		$this->db->join('project_tbl t2', 't2.project_id=t1.project_id');
		$this->db->where('user_id',$user_id);
		$this->db->order_by('created_date', 'DESC');
		$query=$this->db->get();
		$result = $query->result_array();
		return $result;
		
	}
	
    public function update_task($data, $task_id)
    {
        $this->db->where('task_id', $task_id);
        $this->db->update('tasks', $data);
        return true;
        
    }
    

}