<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

	public function check_email_exists($email)
	{
		$this->db->where('email',$email);
		$this->db->select('*');
		$this->db->from('login_tbl');
		$query=$this->db->get();
		$result = $query->row_array();
		return $result;
		/*$log = $query->row_array();
		if(!empty($log)){
			return true;
		}else{
			return false;
		}*/
		
	}
	
	public function edit_user_details($udata, $user_id)
	{
	    $this->db->where('login_id', $user_id);
        $this->db->update('login_tbl', $udata);
        return true;
	}
	
	public function update_temp_password($data, $email)
	{
	    $this->db->where('email', $email);
        $this->db->update('login_tbl', $data);
        return true;
	}
	
	public function get_roles()
	{
	    $this->db->select('t1.*');
	    $this->db->from('roles_tbl t1');
	    $this->db->where('t1.role_id!=',1);
	    $query=$this->db->get();
		$result = $query->result_array();
		return $result;
	}



}