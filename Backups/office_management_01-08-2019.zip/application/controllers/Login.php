<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller {

	public function __construct()
	{
	    parent::__construct();
		$this->load->database();
		$this->load->model('login_model');
		
	}
	
	public function index()
	{		
		if($this->session->userdata('loggedin') == 1){
			redirect('project');
		}
		
		//$data['branches'] = $this->common_model->get_recordset('branch');
		$this->load->view('admin/login');
	
	}
	
	 public function checklogin()
	 {

	 	$uname = $this->input->post('username');
	 	$pass = $this->input->post('password');
	 	$this->form_validation->set_rules('username', 'Username', 'trim|required');
	 	$this->form_validation->set_rules('password', 'Password', 'trim|required');
	 	
		$checklogin = $this->login_model->login($uname,$pass);
		$logindata = $this->login_model->logindata($uname,$pass);
		
    		if($checklogin == 1){
    			$this->session->set_userdata('loggedin',1);
    			$this->session->set_userdata('user_id',$logindata['login_id']);
    			$this->session->set_userdata('user_type',$logindata['type']);
    			$this->session->set_userdata('user_role',$logindata['role']);
    			$this->session->set_userdata('user_email',$logindata['email']);
    			$this->session->set_userdata('user_name',$logindata['name']);
    
    			redirect('tasks');
    		}
    		else
    		{
    			$this->session->set_flashdata('msg','Username or Password Incorrect');
    			redirect('login');
    		}	

	 	}







}
