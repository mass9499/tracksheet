<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class masters extends CI_Controller {

	public function __construct()
	{
	    date_default_timezone_set('Asia/Kolkata');
	    parent::__construct();
		$this->load->database();
		if($this->session->userdata('loggedin') != '1')
		{
		    redirect('login');
		}
	}

	public function index()
	{
		$data['title'] = 'Leave Types';
		$data['subtitle'] = '';
		
		$id = $this->session->userdata('userid');		
		
		$this->load->view('admin/templates/header', $data);
		$this->load->view('admin/leave_types');
		$this->load->view('admin/templates/footer');
	}
	
	public function leave_types()
	{
		$data['title'] = 'Leave Types';
		$data['subtitle'] = '';
		$data['leave_types'] = $this->db->get('leave_types_tbl')->result_array();
		$this->load->view('admin/templates/header', $data);
		$this->load->view('admin/leave_types', $data);
		$this->load->view('admin/templates/footer');
	}
	
	public function leave_type_add()
	{
	    $data['leave_type'] = $this->input->post('leavetype');
	    $data['leave_days'] = $this->input->post('leavedays');
	    $data['created_date'] = date('Y-m-d H:i:s');
	    $data['created_by'] = $this->session->userdata('user_id');
	    
	    if($this->db->insert('leave_types_tbl', $data)) {
	        $this->session->set_flashdata('masters_1', '<strong>Success! </strong>Leave type added successfully.');
	    } else {
	        $this->session->set_flashdata('masters_0', '<strong>Failed! </strong>Leave type not saved.');
	    }
	    redirect('masters/leave_types');
	}
	
	public function adduser()
	{
		$data['title'] = 'Users';
		$data['subtitle'] = 'Add User';
		
		$id = $this->session->userdata('userid');		

		$this->load->view('admin/templates/header', $data);
		$this->load->view('admin/useradd');
		$this->load->view('admin/templates/footer');
	}
	public function edit_user_view($login_id)
	{
	    $data['title'] = 'Users';
		$data['subtitle'] = 'Edit User';
		$data['user'] = $this->db->get_where('login_tbl', array('login_id'=>$login_id))->row_array();
		$this->load->view('admin/templates/header', $data);
		$this->load->view('admin/useredit');
		$this->load->view('admin/templates/footer');
	}
	public function adddusersave()
	{
	    if($this->session->userdata['user_id'] = 73 || $this->session->userdata['user_id'] = 75) {
	        date_default_timezone_set('Asia/Kolkata');
	    } else {
	        date_default_timezone_set('Australia/Sydney');
	    }
	    
		$udata['name'] = $this->input->post('username');
		$udata['email'] = $this->input->post('useremail');
		$udata['password'] = md5($this->input->post('userpassword'));
		$udata['type'] = 'user';
		$udata['status']=1;
		//$id = $this->session->userdata('userid');	
		$udata['created_time'] = date('Y-m-d H:i:s');
		$udata['created_by'] = $this->session->userdata('user_id');
		
		if($this->db->insert('login_tbl', $udata)) {
	        $this->session->set_flashdata('user_add_success', 'User created successfully!');   
	    } else {
	        $this->session->set_flashdata('user_add_failed', 'Failed to create User!');   
	    }
		redirect('user');
		
	}
	
	public function editusersave()
	{
	    if($this->session->userdata['user_id'] = 73 || $this->session->userdata['user_id'] = 75) {
	        date_default_timezone_set('Asia/Kolkata');
	    } else {
	        date_default_timezone_set('Australia/Sydney');
	    }
	    
	    
	    $user_id = $this->input->post('user_id');
	    $userrow = $this->db->get_where('login_tbl', array('login_id'=>$user_id))->row_array();
	    
		$udata['name'] = $this->input->post('username');
		$udata['email'] = $this->input->post('useremail');
		$password = $this->input->post('userpassword');
		if($password == $userrow['password']) {
		    $udata['password'] = $password;
		} else {
		    $udata['password'] = md5($this->input->post('userpassword'));
		}
		$udata['type'] = 'user';
		$udata['status']=1;
		
		if($this->user_model->edit_user_details($udata, $user_id)) {
	        $this->session->set_flashdata('user_edit_success', 'User details updated successfully!');   
	    } else {
	        $this->session->set_flashdata('user_edit_failed', 'Failed to update user details!');   
	    }
		redirect('user');
		
	}
	
	public function recover_login()
	{
	    $email = $this->input->post('email');
	    $uniqid = uniqid();
	    $data['temp_pass'] = md5($uniqid);
	    
	    $exists = $this->user_model->check_email_exists($email);
	    
	    if(!empty($exists)) {
		$this->user_model->update_temp_password($data, $email);
	        
	        $this->session->set_flashdata('login_recovery_success', 'A new password has sent to your registered email.<br> You can use it temporarily.');
	    } else {
	        $this->session->set_flashdata('login_recovery_failed', 'The email you entered is unavailable in our server!<br> Please enter the existing one.');
	    }
	    
	    redirect('login');
	    
	}
	
	
}
