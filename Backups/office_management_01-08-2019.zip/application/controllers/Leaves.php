<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Leaves extends CI_Controller {

	public function __construct()
	{
	    date_default_timezone_set('Asia/Kolkata');
	    parent::__construct();
		$this->load->database();
        if($this->session->userdata('loggedin') != '1')
		{
		    redirect('login');
		}
		$this->load->model('leaves_model');
	}
    public function index()
    {
        $data['title'] = 'Leaves';
		$data['subtitle'] = 'Users List';
		$log_user_id = $this->session->userdata('user_id');
        $log_user_type = $this->session->userdata('user_type');
            if($log_user_type == 'superadmin') {
                $data['users']= $this->db->get_where('login_tbl',array('type' => 'user'))->result_array();
            } else {
                $data['users']= $this->db->get_where('login_tbl',array('login_id' => $log_user_id))->result_array();
            }
        $this->load->view('admin/templates/header', $data);
		$this->load->view('admin/user_leaves');
		$this->load->view('admin/templates/footer');
    }
    
    public function user_leaves($user_id)
    {
        $data['title'] = 'Leaves';
		$data['subtitle'] = 'User Leaves';
		$data['userid'] = $user_id;
		$log_user_type = $this->session->userdata('user_type');
		$data['user_id'] = $user_id;
		$data['leave_types'] = $this->db->order_by('leave_type', 'DESC')->get_where('leave_types_tbl')->result_array();
		$data['leaves'] = $this->db->order_by('created_date', 'DESC')->get_where('leaves_tbl', array('user_id'=>$user_id))->result_array();
        $this->load->view('admin/templates/header', $data);
		$this->load->view('admin/user_leaves_view', $data);
		$this->load->view('admin/templates/footer', $data);
    }
    
    public function add_task()
    {
        $data['user_id'] = $this->input->post('userid');
        $data['task_date'] = $this->input->post('taskdate');
        $data['project_id'] = $this->input->post('projectid');
        $data['task_name'] = $this->input->post('taskname');
        $data['task_hours'] = $this->input->post('taskhours');
        $task_status = $this->input->post('taskstatus');
        if($task_status != '') {
            $data['task_status'] = $this->input->post('taskstatus');
        } else {
            $data['task_status'] = 'In Progress';
        }
        $data['created_date'] = date('Y-m-d H:i:s');
        $data['created_by'] = 'User';
        
        if($this->db->insert('tasks', $data)) {
            $this->session->set_flashdata('add_task_response', '<span style="color:green;">Task added successfully</span>');
        } else {
            $this->session->set_flashdata('add_task_response', '<span style="color:maroon;"Failed to add task!');
        }
        
        redirect('tasks/user_task_list/'.$data['user_id']);
        
    }
    
    public function edit_task_ajax()
    {
        $task_id = $this->input->post('taskid');
        $data['task_status'] = $this->input->post('taskstatus');
        if($this->task_model->update_task($data, $task_id)) {
            echo "1";
        } else {
            echo "0";
        }
        
    }
    
    public function task_new()
    {
        $data['title'] = 'Tasks';
		$data['subtitle'] = 'Add Tasks';
        $this->load->view('admin/templates/header', $data);
		$this->load->view('admin/tasksadd');
		$this->load->view('admin/templates/footer');
    }
    public function tasks_add()
    {
        $data['tasks_project']=$this->input->post('tasks_project');
        $data['tasks_name']=$this->input->post('tasks_name');
        $data['tasks_time']=$this->input->post('tasks_time');
        $data['tasks_date']=$this->input->post('tasks_date');
        $data['tasks_assigned_by']=$this->input->post('tasks_assigned_by');
        $data['tasks_status']=$this->input->post('tasks_status');
        $this->db->insert('tasks',$data);
        redirect('tasks');
    }
}