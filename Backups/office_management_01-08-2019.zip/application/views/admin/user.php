
<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>


<section class="content-body" style="min-height:450px;">
    
<?php
    $servername = "localhost";
    $username = "business_office";
    $password = "-D5h=2z91-Em";
    $dbname = "business_office";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } 
    
    $log_user_id = $this->session->userdata('user_id');
    $log_user_type = $this->session->userdata('user_type');
    
    if($log_user_type == 'superadmin') {
        $sql = "SELECT * FROM login_tbl where type != 'superadmin'";
    } else {
        $sql = "SELECT * FROM login_tbl where login_id = '".$log_user_id."'";
    }
        $users = $conn->query($sql);
?>

<center>
    <?php
        if($this->session->flashdata('user_edit_success') != '') 
        {
            echo "<br><h4 style='color:green;' class='flash'>".$this->session->flashdata('user_edit_success')."</h4>";
        }
        
        if($this->session->flashdata('user_edit_failed') != '') 
        {
            echo "<br><h4 style='color:maroon;' class='flash'>".$this->session->flashdata('user_edit_failed')."</h4>";
        }
        
    ?>
</center>

    <div class="col-md-12"><br>
        <div class="row">
            <div class="col-md-12">
                
            <?php if($this->session->userdata('user_type') == 'superadmin') { ?> 
                <a href="<?php echo base_url();?>user/adduser"><button class="btn btn-primary"><i class="fa fa-plus"></i> Create New User</button></a> <br><br>
            <?php } ?>
        		
        		<table id="projectslisttable" class="table table-bordered table-striped" style="background-color:#fff;">
                  <thead>
                    <tr style="background-color:#e2e2e2;">
                      <th class="text-center" scope="col"># Sl no.</th>
                      <th scope="col">Full Name</th>
                      <th scope="col">Email</th>
                      <th scope="col">Created at</th>
                      <?php if($this->session->userdata('user_type') == 'superadmin') { ?> 
                      <th class="text-center" scope="col">Action</th>
                      <?php } ?>
                    </tr>
                  </thead>
                  <tbody>
                      <?php $slno = 1; ?>
                    <?php while($row = $users->fetch_assoc()) { ?>
                        <tr>
                          <td class="text-center"><?php echo $slno++; ?></td>
                          <td><?php echo $row['name']; ?></td>
                          <td><?php echo $row['email']; ?></td>
                          <td><?php echo $row['created_time']; ?></td>
                          <?php if($this->session->userdata('user_type') == 'superadmin') { ?> 
                          <td class="text-center"><a class="btn btn-primary" href="<?php echo base_url(); ?>user/edit_user_view/<?php echo $row['login_id']; ?>">Edit</a></td>
                          <?php } ?>
                        </tr>
                    <?php } ?>
                  </tbody>
                </table>
            </div>
        </div>		
    </div>
</section>

<script>
    $(document).ready(function() {
        $('#userslisttable').DataTable();
    });
</script>

<script>
$(document).ready(function(){    
    $(".flash").fadeOut(3000);  
});
</script>
