<?php

    function get_screen_permission($roleid)
    {
        $CI = &get_instance();
    	$CI->load->database();
    	$CI->load->model('common_model');
    	$get_upermissions = $CI->db->get_where('role_permissions', array('role'=>$roleid))->result_array();
    	return $get_upermissions;
    }
    
    